#eyecandy.py

def pizzaslabs():
	pass
def load_theme():
	pass
def settings():
	pass
